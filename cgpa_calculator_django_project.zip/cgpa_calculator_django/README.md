# CGPA Calculator (Django)

A simple Django web app that calculates semester CGPA and overall CGPA from course grades and credit hours.

## Requirements
- Python 3.10+
- pip

## Setup (Windows)
1. Extract the ZIP file.
2. Open Command Prompt/PowerShell in the extracted `cgpa_calculator_django` folder.
3. Create a virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
4. Install Django:
   ```bash
   pip install -r requirements.txt
   ```
5. Run database migrations:
   ```bash
   python manage.py migrate
   ```
6. Start the development server:
   ```bash
   python manage.py runserver
   ```
7. Open http://127.0.0.1:8000/ in your browser.

## How CGPA is calculated
For each course: `grade points = grade × credit hours`

Semester CGPA: `sum(grade × credit hours) / sum(credit hours)`

Overall CGPA: enter the previous cumulative CGPA and its total completed credits. The app combines those prior totals with the current semester's grade points and credits:
`overall CGPA = (previous CGPA × previous credits + current semester grade points) / (previous credits + current semester credits)`

For a first semester, leave previous CGPA and previous credits as zero.
Grades are numeric grade-point values (for example, 10, 9, 8, 7 on a 10-point scale). Adjust the scale/validation to match your institution if needed.
