from decimal import Decimal, InvalidOperation
from django.shortcuts import render

def index(request):
    context = {"result": None, "error": None}
    if request.method == "POST":
        try:
            count = int(request.POST.get("course_count", "0"))
            if not 1 <= count <= 30:
                raise ValueError("Please enter between 1 and 30 courses.")

            courses = []
            total_credits = Decimal("0")
            total_points = Decimal("0")
            for i in range(1, count + 1):
                name = request.POST.get(f"course_name_{i}", "").strip() or f"Course {i}"
                grade = Decimal(request.POST.get(f"grade_{i}", ""))
                credit = Decimal(request.POST.get(f"credit_{i}", ""))
                if grade < 0 or grade > 10:
                    raise ValueError(f"{name}: grade must be between 0 and 10.")
                if credit <= 0 or credit > 30:
                    raise ValueError(f"{name}: credit hours must be greater than 0 and at most 30.")
                points = grade * credit
                courses.append({
                    "name": name, "grade": grade, "credit": credit,
                    "points": points.quantize(Decimal("0.01")),
                })
                total_credits += credit
                total_points += points

            previous_cgpa = Decimal(request.POST.get("previous_cgpa", "0") or "0")
            previous_credits = Decimal(request.POST.get("previous_credits", "0") or "0")
            if previous_cgpa < 0 or previous_cgpa > 10:
                raise ValueError("Previous CGPA must be between 0 and 10.")
            if previous_credits < 0:
                raise ValueError("Previous completed credits cannot be negative.")

            semester_cgpa = total_points / total_credits
            combined_credits = total_credits + previous_credits
            overall_cgpa = (
                (previous_cgpa * previous_credits + total_points) / combined_credits
                if combined_credits else Decimal("0")
            )
            context["result"] = {
                "courses": courses,
                "total_credits": total_credits.quantize(Decimal("0.01")),
                "total_points": total_points.quantize(Decimal("0.01")),
                "semester_cgpa": semester_cgpa.quantize(Decimal("0.01")),
                "overall_cgpa": overall_cgpa.quantize(Decimal("0.01")),
                "previous_credits": previous_credits,
                "combined_credits": combined_credits.quantize(Decimal("0.01")),
            }
        except (ValueError, InvalidOperation, TypeError, ZeroDivisionError) as exc:
            context["error"] = str(exc) or "Please check your entries and try again."
            context["course_count"] = request.POST.get("course_count", "3")
    return render(request, "calculator/index.html", context)
